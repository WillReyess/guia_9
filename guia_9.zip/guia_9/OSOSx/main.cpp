#include <iostream>
#include "OSOSx.h"

using namespace std;


int main()
{
    ///Creamos un skin tipo Osx
    OSOSx _osx;
    _osx.PintarOSx();
    return 0;
}
