#include <iostream>
#include "OSWindows.h"

using namespace std;

int main()
{
    OSWindows _win;
    _win.PintarWindows();
    return 0;
}
