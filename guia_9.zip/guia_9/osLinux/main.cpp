#include <iostream>

using namespace std;
#include "OSLinux.h"

int main()
{
    ///Creamos un Skin tipo Windows
    OSLinux _lin;
    _lin.PintarLinux();
    return 0;
}
